package project3.floyds;

// An interface that is used to implement the Floyds class.
public interface FloydsI {
    void makeFloyd();
    void printFloyd();
}
