package project3.results;

// Defining an interface.
public interface ResultsI {
    public void printLCS();
    public void printFlyods();
}
