package project3.projectManager;

// Defining an interface.
public interface ProjectManagerI {
    public void runLCS();
    public void runFloyds();
    public Boolean validateInput();
}
