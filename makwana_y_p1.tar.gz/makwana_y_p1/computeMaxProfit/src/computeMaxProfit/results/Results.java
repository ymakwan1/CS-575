package computeMaxProfit.results;

public class Results {
}
