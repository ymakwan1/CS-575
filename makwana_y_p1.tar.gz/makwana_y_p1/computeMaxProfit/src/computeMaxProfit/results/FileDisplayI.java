package computeMaxProfit.results;

public interface FileDisplayI {
}
