package computeMaxProfit.results;

public interface ResultsI extends FileDisplayI, StdoutDisplayI
{
}
