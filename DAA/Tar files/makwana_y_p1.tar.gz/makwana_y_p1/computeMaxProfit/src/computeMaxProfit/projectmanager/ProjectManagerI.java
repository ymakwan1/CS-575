package computeMaxProfit.projectmanager;

public interface ProjectManagerI {
    public void run();
}
