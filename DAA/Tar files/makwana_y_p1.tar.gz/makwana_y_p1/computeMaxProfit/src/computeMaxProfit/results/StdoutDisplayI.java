package computeMaxProfit.results;

public interface StdoutDisplayI {
    public void writeToConsole(String strIn);
}
