package computeMaxProfit.utils;

public interface FileProcessorI {
    public void readMarketPrice(String marketPriceIn);
    public void readPriceList(String priceListIn);
}
