package trominoTiling.results;
public class Results {
    
}
