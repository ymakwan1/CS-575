package project5.results;

public interface ResultsI {
    
}
