package project4.results;

public class Results implements ResultsI{
    
    public Results(){
        
    }
}