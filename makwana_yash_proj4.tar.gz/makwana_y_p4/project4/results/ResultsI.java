package project4.results;


// Defining an interface.
public interface ResultsI {
}
